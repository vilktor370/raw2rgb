from setuptools import setup


setup(
    name='raw2rgb',
    version='0.1.0',
    description='A python tool to convert .tiff image file to .png file',
    packages=['raw2rgb'],
    author='Haochen Yu',
    zip_safe=False
)